import React from 'react';
import { StyleSheet, View, Text, TouchableOpacity, Image, FlatList, ScrollView } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import axios from 'axios';

// Screen to display a grid of states
const StatesGrid = ({ navigation }) => {
  const [states, setStates] = React.useState([]);

  React.useEffect(() => {
    // Fetch all unique states from the backend
    axios
      .get('http://localhost:3000/states')  // Add a proper endpoint if this needs to fetch states list
      .then((response) => {
        setStates(response.data);  // The response will be an array of state names
      })
      .catch((err) => {
        console.error('Error fetching states:', err);
      });
  }, []);

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.heading}>States of India</Text>
      <FlatList
        data={states}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={styles.stateCard}
            onPress={() => navigation.navigate('PlacesGrid', { stateName: item })}
          >
            <Image
              source={{ uri: `https://example.com/${item}-image.jpg` }}  // Replace with actual image source
              style={styles.stateImage}
            />
            <Text style={styles.stateName}>{item}</Text>
          </TouchableOpacity>
        )}
        numColumns={2}
        keyExtractor={(item) => item}
      />
    </ScrollView>
  );
};

// Screen to display a grid of places in a selected state
const PlacesGrid = ({ route, navigation }) => {
  const { stateName } = route.params;
  const [places, setPlaces] = React.useState([]);

  React.useEffect(() => {
    // Fetch places for the selected state
    axios
      .get(`http://localhost:3000/places?state=${stateName}`)
      .then((response) => {
        setPlaces(response.data);  // Assuming response contains a list of places
      })
      .catch((err) => {
        console.error('Error fetching places:', err);
      });
  }, [stateName]);

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.heading}>{stateName} Places</Text>
      <FlatList
        data={places}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={styles.placeCard}
            onPress={() => navigation.navigate('PlaceDetails', { placeName: item.name })}  // Use item.name instead of item._id
          >
            <Image source={{ uri: item.image }} style={styles.placeImage} />
            <Text style={styles.placeName}>{item.name}</Text>
          </TouchableOpacity>
        )}
        numColumns={2}
        keyExtractor={(item) => item._id}
      />
    </ScrollView>
  );
};

// Screen to display details of a selected place
const PlaceDetails = ({ route }) => {
  const { placeName } = route.params;  // Use placeName instead of placeId
  const [place, setPlace] = React.useState(null);

  React.useEffect(() => {
    // Fetch place details by name
    axios
      .get(`http://localhost:3000/place/${encodeURIComponent(placeName)}`)
      .then((response) => {
        setPlace(response.data);  // Assuming response contains place details
      })
      .catch((err) => {
        console.error('Error fetching place details:', err);
      });
  }, [placeName]);

  if (!place) {
    return (
      <View style={styles.container}>
        <Text>Loading place details...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Text style={styles.heading}>{place.name}</Text>
      <Image source={{ uri: place.image }} style={styles.placeDetailImage} />
      <Text>{place.address}</Text>
      <Text>{place.contact}</Text>
      <Text>{place.historical_info}</Text>
      <Text>{place.tourism_info}</Text>
    </View>
  );
};

// Set up React Navigation
const Stack = createStackNavigator();

const App = () => {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="StatesGrid">
        <Stack.Screen name="StatesGrid" component={StatesGrid} />
        <Stack.Screen name="PlacesGrid" component={PlacesGrid} />
        <Stack.Screen name="PlaceDetails" component={PlaceDetails} />
      </Stack.Navigator>
    </NavigationContainer>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    padding: 10,
  },
  heading: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginVertical: 10,
  },
  stateCard: {
    flex: 1,
    margin: 10,
    borderRadius: 10,
    backgroundColor: '#f0f0f0',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  stateImage: {
    width: 150,
    height: 100,
    borderRadius: 10,
  },
  stateName: {
    fontSize: 16,
    fontWeight: 'bold',
    textAlign: 'center',
    marginTop: 10,
  },
  placeCard: {
    flex: 1,
    margin: 10,
    borderRadius: 10,
    backgroundColor: '#f0f0f0',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  placeImage: {
    width: 150,
    height: 100,
    borderRadius: 10,
  },
  placeName: {
    fontSize: 16,
    fontWeight: 'bold',
    textAlign: 'center',
    marginTop: 10,
  },
  placeDetailImage: {
    width: 300,
    height: 200,
    borderRadius: 10,
    marginBottom: 10,
  },
});

export default App;
