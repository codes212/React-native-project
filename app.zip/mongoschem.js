const mongoose = require('mongoose');

const placeSchema = new mongoose.Schema({
    name: { type: String, required: true },
    address: { type: String },
    contact: { type: String },
    facilities: [String],  // Array of facilities
    transportation: [String],  // Array of transportation types
    historical_info: { type: String },
    tourism_info: { type: String },
    state: { type: String, required: true }  // Added the state field
  });
  